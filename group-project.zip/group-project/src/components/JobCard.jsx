export function JobCard({ title, name, location, salary, children }) {
  return (
    <>
      <h3>{title}</h3>
      <p>{name}</p>
      <p>{location}</p>
      <p>{salary}</p>
      {children}
    </>
  );
}
