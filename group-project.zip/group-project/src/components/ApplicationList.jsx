import { JobCard } from "./JobCard.jsx";

export function ApplicationList() {
  const jobs = [
    {
      id: 1,
      title: "Frontend Developer",
      name: "TechCorp",
      location: "Cape Town",
      salary: "R25,000",
    },
    {
      id: 2,
      title: "Backend Developer",
      name: "DevWorks",
      location: "Johannesburg",
      salary: "R30,000",
    },
    {
      id: 3,
      title: "Fullstack Engineer",
      name: "CodeBase",
      location: "Durban",
      salary: "R35,000",
    },
  ];
  return (
    <>
      {jobs.map((job) => {
        return (
          <JobCard
            key={job.id}
            title={job.title}
            name={job.name}
            location={job.location}
            salary={job.salary}
          >
            Application in progress...
          </JobCard>
        );
      })}
      <p>Application Progress</p>
    </>
  );
}
