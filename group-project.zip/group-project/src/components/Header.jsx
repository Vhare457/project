import { Link } from "react-router";
import NextStep from "../assets/NextStep.png";

export function Header() {
  return (
    <header>
      <Link to="/home">
        {" "}
        <img
          className="logo"
          src={NextStep}
          style={{ width: "100px", height: "40px" }}
        ></img>
      </Link>
      <Link to="/messages">
        <button>Messages</button>
      </Link>
      <Link to="/applications">
        <button>Applications</button>
      </Link>
      <button>Notifications</button>
      <Link to="/profile">
        <button>Profile</button>
      </Link>
    </header>
  );
}
