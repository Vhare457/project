import { Link } from "react-router";
import NextStep from "../assets/NextStep.png";

export function Header() {
  return (
    <header>
      <Link to="/jobseeker/home">
        {" "}
        <img
          className="logo"
          src={NextStep}
          style={{ width: "100px", height: "40px" }}
        ></img>
      </Link>
      <Link to="/jobseeker/messages">
        <button>Messages</button>
      </Link>
      <Link to="/jobseeker/applications">
        <button>Applications</button>
      </Link>
      <button>Notifications</button>
      <Link to="/jobseeker/profile">
        <button>Profile</button>
      </Link>
    </header>
  );
}
