import { Link } from "react-router";
import NextStep from "../assets/NextStep.png";
export function EmployerHeader() {
  return (
    <header className="d-flex align-items-center justify-content-between px-3 py-2">
      {" "}
      <Link to="/employer/home">
        {" "}
        <img
          className="logo"
          src={NextStep}
          alt="Logo"
          style={{ width: "140px", height: "50px" }}
        />{" "}
      </Link>{" "}
      <div className="d-flex align-items-center gap-3">
        {" "}
        <Link to="/employer/messages">
          {" "}
          <i className="bi bi-chat fs-1 text-dark"></i>
        </Link>{" "}
        <Link to="/employer/assessments">
          {" "}
          <i className="bi bi-pencil-square fs-1 text-dark"></i>{" "}
        </Link>{" "}
        <i className="bi bi-bell fs-1 text-dark"></i>{" "}
        <div className="dropdown">
          {" "}
          <i
            className="bi bi-person-circle fs-1 text-dark dropdown-toggle"
            role="button"
            id="profileDropdown"
            data-bs-toggle="dropdown"
            aria-expanded="false"
            style={{ cursor: "pointer", lineHeight: "1" }}
          ></i>{" "}
          <ul
            className="dropdown-menu dropdown-menu-end"
            aria-labelledby="profileDropdown"
          >
            <li>
              <Link className="dropdown-item" to="/jobseeker/profile">
                Profile
              </Link>
            </li>
            <li>
              <Link className="dropdown-item" to="/employer/messages">
                My messages
              </Link>
            </li>

            <li>
              <Link className="dropdown-item" to="/employer/assessments">
                My assessments
              </Link>
            </li>
            <li>
              <hr className="dropdown-divider" />
            </li>
            <li>
              <Link className="dropdown-item text-danger" to="/">
                Logout
              </Link>
            </li>
          </ul>
        </div>{" "}
      </div>{" "}
    </header>
  );
}
