import { Link } from "react-router";
import NextStep from "../assets/NextStep.png";
export function AdminHeader() {
  return (
    <header className="d-flex align-items-center justify-content-between px-3 py-2">
      {" "}
      <Link to="/admin/home">
        {" "}
        <img
          className="logo"
          src={NextStep}
          alt="Logo"
          style={{ width: "140px", height: "50px" }}
        />{" "}
      </Link>{" "}
      <div className="d-flex align-items-center gap-3">
        {" "}
        <Link to="/admin/users">
          {" "}
          <i className="bi bi-people fs-1 text-dark"></i>{" "}
        </Link>{" "}
        <Link to="/jobseeker/assessments">
          {" "}
          <i className="bi bi-card-list fs-1 text-dark"></i>{" "}
        </Link>{" "}
        <Link to="/admin/faqs">
          {" "}
          <i className="bi bi-patch-question fs-1 text-dark"></i>{" "}
        </Link>{" "}
        <Link to="/admin/notifications">
          <i className="bi bi-bell fs-1 text-dark"></i>{" "}
        </Link>
        <div className="dropdown">
          {" "}
          <i
            className="bi bi-person-circle fs-1 text-dark dropdown-toggle"
            role="button"
            id="profileDropdown"
            data-bs-toggle="dropdown"
            aria-expanded="false"
            style={{ cursor: "pointer", lineHeight: "1" }}
          ></i>{" "}
          <ul
            className="dropdown-menu dropdown-menu-end"
            aria-labelledby="profileDropdown"
          >
            <li>
              <Link className="dropdown-item" to="/jobseeker/profile">
                Profile
              </Link>
            </li>
            <li>
              <Link className="dropdown-item" to="/jobseeker/messages">
                Messages
              </Link>
            </li>
            <li>
              <Link className="dropdown-item" to="/jobseeker/applications">
                My Applications
              </Link>
            </li>
            <li>
              <Link className="dropdown-item" to="/jobseeker/assessments">
                My Assessments
              </Link>
            </li>
            <li>
              <hr className="dropdown-divider" />
            </li>
            <li>
              <Link className="dropdown-item text-danger" to="/">
                Logout
              </Link>
            </li>
          </ul>
        </div>{" "}
      </div>{" "}
    </header>
  );
}
