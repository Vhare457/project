import { Routes, Route } from "react-router";
import { JobSeekerHome } from "./pages/jobSeeker/JobSeekerHome";
import { Messages } from "./pages/jobSeeker/Messages";
import { MyApplications } from "./pages/jobSeeker/MyApplications";
import { JobSeekerProfile } from "./pages/jobSeeker/JobSeekerProfile";
import { Login } from "./pages/auth/login";
import { ProfileCreation } from "./pages/auth/ProfileCreation";
import { PasswordReset } from "./pages/auth/PasswordReset";
import { EmployerProfileCreation } from "./pages/auth/EmployerProfileCreation";
import { JobSeekerProfileCreation } from "./pages/auth/JobSeekerProfileCreation";
import { EmployerHome } from "./pages/employer/EmployerHome";

function App() {
  return (
    <Routes>
      <Route index element={<Login />} />
      <Route path="/jobseeker/home" element={<JobSeekerHome />} />
      <Route path="/jobseeker/profile" element={<JobSeekerProfile />} />
      <Route path="/jobseeker/messages" element={<Messages />} />
      <Route path="/jobseeker/applications" element={<MyApplications />} />
      <Route
        path="/jobseeker/creation"
        element={<JobSeekerProfileCreation />}
      />
      <Route path="/creation" element={<ProfileCreation />} />
      <Route path="/reset" element={<PasswordReset />} />
      <Route path="/employer/creation" element={<EmployerProfileCreation />} />
      <Route path="/employer/home" element={<EmployerHome />} />
    </Routes>
  );
}

export default App;
