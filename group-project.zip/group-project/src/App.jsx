import { Routes, Route } from "react-router";
import { LoginPage } from "./pages/auth/LoginPage";
import { HomePage } from "./pages/user/HomePage";
import { MessagesPage } from "./pages/user/MessagesPage";
import { MyApplicationsPage } from "./pages/user/MyApplicationsPage";
import { ProfilePage } from "./pages/user/ProfilePage";

function App() {
  return (
    <Routes>
      <Route index element={<LoginPage />} />
      <Route path="/home" element={<HomePage />} />
      <Route path="/profile" element={<ProfilePage />} />
      <Route path="/messages" element={<MessagesPage />} />
      <Route path="/applications" element={<MyApplicationsPage />} />
    </Routes>
  );
}

export default App;
