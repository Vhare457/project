import { Routes, Route } from "react-router";
import { JobSeekerHome } from "./pages/jobSeeker/JobSeekerHome";
import { JobSeekerMessages } from "./pages/jobSeeker/JobSeekerMessages";
import { MyApplications } from "./pages/jobSeeker/MyApplications";
import { JobSeekerProfile } from "./pages/jobSeeker/JobSeekerProfile";
import { Login } from "./pages/auth/login";
import { ProfileCreation } from "./pages/auth/ProfileCreation";
import { PasswordReset } from "./pages/auth/PasswordReset";
import { EmployerProfileCreation } from "./pages/auth/EmployerProfileCreation";
import { JobSeekerProfileCreation } from "./pages/auth/JobSeekerProfileCreation";
import { EmployerHome } from "./pages/employer/EmployerHome";
import { JobSeekerAssessment } from "./pages/jobSeeker/JobSeekerAssessment";
import { AdminHomePage } from "./pages/admin/AdminHomePage";
import { EmployerAssessments } from "./pages/employer/EmployerAssessments";
import { EmployerMessages } from "./pages/employer/EmployerMessages";
import { UserManagement } from "./pages/admin/UserManagement";
import { FAQS } from "./pages/admin/FAQS";
import { AdminNotifications } from "./pages/admin/AdminNotifications";

function App() {
  return (
    <>
      <title>NextStep - Job Portal</title>
      <Routes>
        <Route index element={<Login />} />
        <Route path="/jobseeker/home" element={<JobSeekerHome />} />
        <Route path="/jobseeker/profile" element={<JobSeekerProfile />} />
        <Route path="/jobseeker/messages" element={<JobSeekerMessages />} />
        <Route path="/jobseeker/applications" element={<MyApplications />} />
        <Route
          path="/jobseeker/assessments"
          element={<JobSeekerAssessment />}
        />
        <Route
          path="/jobseeker/creation"
          element={<JobSeekerProfileCreation />}
        />
        <Route path="/creation" element={<ProfileCreation />} />
        <Route path="/reset" element={<PasswordReset />} />
        <Route
          path="/employer/creation"
          element={<EmployerProfileCreation />}
        />
        <Route path="/employer/home" element={<EmployerHome />} />
        <Route path="/admin/home" element={<AdminHomePage />} />
        <Route path="/employer/assessments" element={<EmployerAssessments />} />
        <Route path="/employer/messages" element={<EmployerMessages />} />
        <Route path="/admin/users" element={<UserManagement />} />
        <Route path="/admin/faqs" element={<FAQS />} />
        <Route path="/admin/notifications" element={<AdminNotifications />} />
      </Routes>
    </>
  );
}

export default App;
