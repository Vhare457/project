import { Link } from "react-router";

export function ProfileCreation() {
  return (
    <>
      <p>Who are you?</p>
      <Link to="/employer/creation">
        <button>An employer</button>
      </Link>
      <Link to="/jobseeker/creation">
        <button>A job seeker</button>
      </Link>
      <Link to="/">
        <button>Back</button>
      </Link>
    </>
  );
}
