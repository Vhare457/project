import { Link } from "react-router";

export function PasswordReset() {
  return (
    <>
      <h2>Forgot password</h2>
      <input placeholder="Email" />
      <p>Verification code will be sent to this email address</p>
      <button>Next</button>

      <Link to="/">
        <button>Back</button>
      </Link>
    </>
  );
}
