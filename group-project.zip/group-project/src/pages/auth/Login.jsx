import { Link } from "react-router";
import NextStep from "../../assets/NextStep.png";

export function Login() {
  return (
    <>
      <img
        className="logo"
        src={NextStep}
        style={{ width: "100px", height: "40px" }}
      ></img>
      Ready to take the next step?
      <h2>Sign in</h2>
      <input placeholder="Email or phone"></input>
      <input placeholder="Password"></input>
      <Link to="/reset">Forgot password?</Link>
      <label>
        <input type="checkbox" name="keepLoggedIn" />
        Keep me logged in
      </label>
      <Link to="/jobseeker/home">
        <button>Sign in as job seeker</button>
      </Link>
      <Link to="/employer/home">
        <button>Sign in as employer</button>
      </Link>
      <div>
        <Link to="/creation">New to NextStep? Create Account</Link>
      </div>
    </>
  );
}
