import { Link } from "react-router";
import NextStep from "../../assets/NextStep.png";

export function Login() {
  return (
    <>
      <header className="d-flex align-items-center justify-content-center px-3 py-2">
        <img
          className="logo"
          src={NextStep}
          alt="Logo"
          style={{ width: "140px", height: "50px" }}
        />
      </header>
      <div className="d-flex justify-content-center">
        <div>
          Ready to take the next step?
          <h2>Sign in</h2>
          <div style={{ maxWidth: "350px" }}>
            <form>
              <div className="mb-3">
                <label for="exampleInputEmail1" className="form-label">
                  Email address
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="exampleInputEmail1"
                  aria-describedby="emailHelp"
                />
              </div>
              <div className="mb-3">
                <label for="exampleInputPassword1" className="form-label">
                  Password
                </label>
                <input
                  type="password"
                  className="form-control"
                  id="exampleInputPassword1"
                />
              </div>
            </form>
          </div>
          <label>
            <input type="checkbox" name="keepLoggedIn" />
            Keep me logged in
          </label>
          <div>
            <Link to="/jobseeker/home">
              <button type="button" className="btn btn-primary">
                Sign in as job seeker
              </button>
            </Link>
            <Link to="/employer/home">
              <button type="button" className="btn btn-primary">
                Sign in as employer
              </button>
            </Link>
            <Link to="/admin/home">
              <button type="button" className="btn btn-primary">
                Sign in as admin
              </button>
            </Link>
          </div>
          <Link to="/reset">Forgot password?</Link>
          <div>
            <Link to="/creation">New to NextStep? Create Account</Link>
          </div>
        </div>
      </div>
    </>
  );
}
