import { Link } from "react-router";
import NextStep from "../../assets/NextStep.png";

export function LoginPage() {
  return (
    <>
      <img
        className="logo"
        src={NextStep}
        style={{ width: "100px", height: "40px" }}
      ></img>
      Ready to take the next step?
      <h2>Sign in</h2>
      <input placeholder="Email or phone"></input>
      <input placeholder="Password"></input>
      <Link>Forgot password?</Link>
      <label>
        <input type="checkbox" name="keepLoggedIn" />
        Keep me logged in
      </label>
      <Link to="/home">
        <button>Sign in</button>
      </Link>
      <div>
        <Link>New to NextStep? Create Account</Link>
      </div>
    </>
  );
}
