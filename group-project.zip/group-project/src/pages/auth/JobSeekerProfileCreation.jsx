import { Link } from "react-router";

export function JobSeekerProfileCreation() {
  return (
    <>
      <input placeholder="Name"></input>
      <input placeholder="Surname"></input>
      <input placeholder="Email"></input>
      <input placeholder="Phone number"></input>

      <button>Create Account</button>

      <Link to="/creation">
        <button>Back</button>
      </Link>
    </>
  );
}
