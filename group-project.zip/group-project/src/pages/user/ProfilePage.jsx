import { Header } from "../../components/Header";

export function ProfilePage() {
  return (
    <>
      <Header />
    </>
  );
}
