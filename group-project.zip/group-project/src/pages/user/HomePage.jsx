import { Header } from "../../components/Header";
import { JobList } from "../../components/JobList";

export function HomePage() {
  return (
    <>
      <title>NextStep</title>

      <Header />
      <input placeholder="Job Title" />
      <input placeholder="City/Surburb" />
      <JobList />
    </>
  );
}
