import { Header } from "../../components/Header";

export function MyApplicationsPage() {
  return (
    <>
      <Header />
    </>
  );
}
