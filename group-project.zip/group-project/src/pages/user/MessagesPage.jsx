import { Header } from "../../components/Header";

export function MessagesPage() {
  return (
    <>
      <Header />
    </>
  );
}
