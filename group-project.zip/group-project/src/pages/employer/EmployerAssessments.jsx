import { EmployerHeader } from "../../components/EmployerHeader";

export function EmployerAssessments() {
  return (
    <>
      <EmployerHeader />
    </>
  );
}
