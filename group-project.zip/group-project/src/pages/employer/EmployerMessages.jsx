import { EmployerHeader } from "../../components/EmployerHeader";

export function EmployerMessages() {
  return (
    <>
      <EmployerHeader />
    </>
  );
}
