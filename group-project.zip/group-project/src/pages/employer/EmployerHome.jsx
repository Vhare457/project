import { EmployerJobList } from "../../components/EmployerJobList";

export function EmployerHome() {
  return (
    <>
      <h2>Jobs advertised</h2>
      <button>Add new Job</button>
      <p>Your job postings</p>
      <EmployerJobList />
    </>
  );
}
