import { EmployerJobList } from "../../components/EmployerJobList";
import { EmployerHeader } from "../../components/EmployerHeader";
import { Link } from "react-router";

export function EmployerHome() {
  return (
    <>
      <EmployerHeader />
      <Link>
        <i className="bi bi-plus fs-1 text-dark"></i>
      </Link>
      <EmployerJobList />
    </>
  );
}
