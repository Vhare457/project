export function JobSeekerAssessment() {
  return <></>;
}
