import { JobSeekerHeader } from "../../components/JobSeekerHeader";

export function JobSeekerProfile() {
  return (
    <>
      <JobSeekerHeader />

      <div className="container my-4">
        <div className="row">
          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Left Sidebar</h5>
            </div>
          </div>

          <div className="col-12 col-md-6">
            <div
              className="d-flex align-items-center border rounded overflow-hidden mb-4"
              style={{ width: "100%" }}
            >
              <div>
                <h2>Basic info</h2>
                <p>Name</p>
                <p>Birthday</p>
                <p>Gender</p>

                <h2>Contact info</h2>
                <p>Email</p>
                <p>Phone number</p>

                <h2>Adresses</h2>
                <p>Home</p>

                <button className="btn btn-primary">Edit profile</button>
              </div>
            </div>
          </div>

          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Right Sidebar</h5>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
