import { JobSeekerHeader } from "../../components/JobSeekerHeader";
import { JobList } from "../../components/JobList";

export function JobSeekerHome() {
  return (
    <>
      <JobSeekerHeader />

      <div className="container my-4">
        <div className="row">
          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Left Sidebar</h5>
            </div>
          </div>

          <div className="col-12 col-md-6">
            <div
              className="d-flex align-items-center border rounded overflow-hidden mb-4"
              style={{ width: "100%" }}
            >
              <input
                type="text"
                className="form-control border-0"
                placeholder="Job Title"
                style={{ flex: 1, padding: "0.5rem 1rem" }}
              />
              <div style={{ width: "1px", backgroundColor: "#ccc" }} />
              <input
                type="text"
                className="form-control border-0"
                placeholder="City/Suburb"
                style={{ flex: 1, padding: "0.5rem 1rem" }}
              />
              <button className="btn btn-primary" style={{ borderRadius: 0 }}>
                Search
              </button>
            </div>

            <JobList />
          </div>

          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Right Sidebar</h5>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
