import { Header } from "../../components/Header";
import { JobList } from "../../components/JobList";

export function JobSeekerHome() {
  return (
    <>
      <title>NextStep</title>

      <Header />
      <input placeholder="Job Title" />
      <input placeholder="City/Surburb" />
      <JobList />
    </>
  );
}
