import { Header } from "../../components/Header";

export function Messages() {
  return (
    <>
      <Header />
    </>
  );
}
