import { JobSeekerHeader } from "../../components/JobSeekerHeader";
import { ApplicationList } from "../../components/ApplicationList";
import App from "../../App";

export function MyApplications() {
  return (
    <>
      <JobSeekerHeader />
      <div className="container my-4">
        <div className="row">
          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Left Sidebar</h5>
            </div>
          </div>

          <div className="col-12 col-md-6">
            <div
              className="d-flex align-items-center border rounded overflow-hidden mb-4"
              style={{ width: "100%" }}
            >
              <div>
                <ApplicationList />
              </div>
            </div>
          </div>

          <div className="col-3 d-none d-md-block">
            <div className="p-3 border rounded">
              <h5>Right Sidebar</h5>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
