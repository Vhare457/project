import { Header } from "../../components/Header";
import { ApplicationList } from "../../components/ApplicationList";

export function MyApplications() {
  return (
    <>
      <Header />
      <ApplicationList />
    </>
  );
}
