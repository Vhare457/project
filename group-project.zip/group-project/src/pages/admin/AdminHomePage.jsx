import { AdminHeader } from "../../components/AdminHeader";

export function AdminHomePage() {
  return (
    <>
      <AdminHeader />
      Hello
      <h1>hi</h1>
    </>
  );
}
