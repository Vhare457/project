import { AdminHeader } from "../../components/AdminHeader";

export function UserManagement() {
  return (
    <>
      <AdminHeader />
      User Management Page
    </>
  );
}
