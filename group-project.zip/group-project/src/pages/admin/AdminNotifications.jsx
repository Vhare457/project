import { AdminHeader } from "../../components/AdminHeader";

export function AdminNotifications() {
  return (
    <>
      <AdminHeader />
      Admin Notifications Page
    </>
  );
}
