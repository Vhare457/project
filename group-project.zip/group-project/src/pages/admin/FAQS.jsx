import { AdminHeader } from "../../components/AdminHeader";

export function FAQS() {
  return (
    <>
      <AdminHeader />
      FAQS Page
    </>
  );
}
